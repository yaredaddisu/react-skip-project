 
function App() {
 
  return (
    <>
      <h1 className='text-3xl font-bold underline bg-red-500 text-center'>Hello World</h1>
    </>
  )
}

export default App
